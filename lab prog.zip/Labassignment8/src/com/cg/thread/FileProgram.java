package com.cg.thread;

import com.cg.thread.CopyDataThread;

public class FileProgram {

		public static void main(String[] args) {
			System.out.println(Thread.currentThread()); 
			Thread t1= new CopyDataThread("worker-1");
			t1.start();
			
			

		}

	
	
}
