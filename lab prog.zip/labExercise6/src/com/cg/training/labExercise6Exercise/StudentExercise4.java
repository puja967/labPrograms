package com.cg.training.labExercise6Exercise;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class StudentExercise4 {

	public static void main(String[] args) {
		HashMap<String, Integer> hashMap=new HashMap<String, Integer>();
		hashMap.put("101", 98);
		hashMap.put("102", 85);
		hashMap.put("103", 74);
		hashMap.put("104", 35);
		hashMap.put("101", 67);
		HashMap<String, String> output=getStudents(hashMap);
		System.out.println("students details:" +output);
	}
	private static HashMap<String, String> getStudents(HashMap<String, Integer> hashMap)
	{
		HashMap<String, String> result=new HashMap<>();
		Set<String> s=hashMap.keySet();
		Iterator<String> i=s.iterator();
		while(i.hasNext())
		{
			String str=i.next();
			int mark=hashMap.get(str);
			if(mark>=90)
				result.put(str, "GOLD");
			else if(mark>=80 && mark<90)
				result.put(str, "SILVER");
			else if(mark>=70 && mark<80)
				result.put(str, "BRONZE");	
		}
		return result;
	}

}
